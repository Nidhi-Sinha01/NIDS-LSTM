# Intrusion-Detection-System-using-LSTM
The dataset used is UNSW-NB15 
